MY SAVINGS – ANDROID PROJECT

This is the Android WebView app project for My Savings (AED).
It stores records locally on the device using browser local storage.

BUILD ON GITHUB USING A PHONE
1. Create/sign in to a GitHub account.
2. Create a new repository named MySavingsAndroid.
3. Upload all files and folders from this ZIP to the repository root.
   Make sure hidden folders such as .github are included.
4. Open the repository's Actions tab.
5. Select "Build My Savings APK" and tap "Run workflow".
6. When the workflow finishes, open the run and download the
   "My-Savings-APK" artifact. Extract it to get app-debug.apk.
7. Open the APK on your Android phone and allow installation from
   that source if Android asks.

NOTES
- This is a debug APK for personal testing, not a Play Store release.
- Keep backups of your money records using the app's Backup button.
- The app is offline; data stays in this app's local storage.
- If you uninstall or clear app data, local records may be lost.
